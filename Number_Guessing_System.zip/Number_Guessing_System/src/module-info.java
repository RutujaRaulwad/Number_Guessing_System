/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module Number_Guessing_System {
}