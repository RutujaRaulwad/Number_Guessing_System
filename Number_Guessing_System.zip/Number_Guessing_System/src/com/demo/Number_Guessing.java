package com.demo;
import java.util.Random;
import java.util.Scanner;

	public class Number_Guessing 
	{
		    public static void main(String[] args) 
		    {
		        Scanner scanner = new Scanner(System.in);
		        Random random = new Random();

		        int lowest = 1;
		        int highest = 100;
		        int targetNum = random.nextInt(highest - lowest + 1) + lowest ;
		        int trails = 0;
		        int score = 100;

		        System.out.println("\n    Welcome to the Guess the Number game!"
		        		+ "\n");
		        System.out.println("\n Select a number between " + lowest + " and " + highest + ". AND Try to guess correct number !");

		        while (true) 
		        {
		            System.out.print("\n Enter a guessing number : ");
		            int GuessNumber = scanner.nextInt();
		            trails++;

		            if (GuessNumber == targetNum) 
		            {
		            	System.out.println("");
		                System.out.println("Wow !!!!! You have selected correct number  : " + targetNum);
		                System.out.println(" \n Your score is : " + score);
		                break;
		            } else if (GuessNumber < targetNum) {
		                System.out.println("The number is highest... please try again \n");
		            } else 
		            {
		                System.out.println("The number is lowest ... please try again \n ");
		            }

		            // Decrease the score by 5 for each attempt.
		            score -= 5;

		            if (score <= 0)
		            {
		                score = 0;
		                System.out.println("\n The End.....  The correct number was  : " + targetNum);
		                break;
		            }
		        }

		        System.out.println("\n Game Ends Here ................! \n \n You took " + trails + "  trials to guess the number.");
		        scanner.close();
		    }
}
